# ai-service/src/response_generator.py
"""
Response Generation module
Generates appropriate responses using knowledge base and LLM
"""

import os
import logging
from typing import Dict, List, Any
import requests

logger = logging.getLogger(__name__)

class ResponseGenerator:
    """Generate responses to user queries"""
    
    def __init__(self):
        """Initialize response generator"""
        self.llm_provider = os.getenv('LLM_PROVIDER', 'openai').lower()
        self.openai_api_key = os.getenv('OPENAI_API_KEY')
        self.google_api_key = os.getenv('GOOGLE_API_KEY')
        self.backend_url = os.getenv('BACKEND_URL', 'http://localhost:5000')
        
        logger.info(f"✅ Response Generator initialized (Provider: {self.llm_provider})")
    
    def generate(self, user_message: str, intent: Dict[str, Any], context: Dict = None) -> str:
        """
        Generate response to user message
        
        Args:
            user_message: Original user message
            intent: Intent recognition result
            context: Additional context (conversation history, etc.)
        
        Returns:
            Generated response string
        """
        # Step 1: Retrieve relevant KB entries
        kb_entries = self._retrieve_kb_entries(
            user_message,
            category_id=intent.get('category_id')
        )
        
        # Step 2: Build context for LLM
        context_text = self._build_context(kb_entries, user_message, intent)
        
        # Step 3: Generate response using LLM or template
        if self.llm_provider == 'gemini' and self.google_api_key:
            response = self._generate_with_gemini(user_message, context_text, intent)
        elif self.openai_api_key and self.llm_provider == 'openai':
            response = self._generate_with_openai(user_message, context_text, intent)
        else:
            response = self._generate_with_template(kb_entries, intent)
        
        return response
    
    def _retrieve_kb_entries(self, query: str, category_id: int = None, top_n: int = 5) -> List[Dict]:
        """
        Retrieve relevant KB entries using semantic search
        
        Args:
            query: User query
            category_id: Optional category filter
            top_n: Number of top results
        
        Returns:
            List of relevant KB entries
        """
        try:
            # Get KB entries from backend
            params = {}
            if category_id:
                params['category'] = self._get_category_name(category_id)
            
            response = requests.get(
                f"{self.backend_url}/api/kb",
                params=params,
                timeout=5
            )
            
            if response.status_code != 200:
                logger.warning("Failed to retrieve KB entries from backend")
                return []
            
            all_entries = response.json().get('data', [])
            
            return all_entries[:top_n]
            
        except Exception as e:
            logger.error(f"Error retrieving KB entries: {str(e)}")
            return []
    
    def _build_context(self, kb_entries: List[Dict], query: str, intent: Dict) -> str:
        """
        Build context string for LLM from KB entries
        
        Args:
            kb_entries: Retrieved KB entries
            query: Original query
            intent: Intent information
        
        Returns:
            Context string for LLM
        """
        context = f"""
You are a helpful assistant for The Federal Polytechnic, Ado-Ekiti.
You help students and staff with questions about {intent.get('description', 'institutional services')}.

User Query: {query}

Relevant Information:
"""

        if not kb_entries:
            context += "\nNo exact match was found in the local knowledge base. Use general institutional knowledge, answer in a conversational tone, and if the answer is time-sensitive or official, advise the user to confirm on the official website or the relevant office.\n"
        else:
            for i, entry in enumerate(kb_entries, 1):
                context += f"\n{i}. Q: {entry.get('question', '')}\n   A: {entry.get('answer', '')}\n"

        context += "\nBased on the above information, provide a helpful, natural, and accurate response. If exact official details are missing, say so politely and recommend the official school website or the relevant department."

        return context
    
    def _generate_with_gemini(self, query: str, context: str, intent: Dict) -> str:
        """Generate response using Google Gemini API."""
        try:
            import google.generativeai as genai

            genai.configure(api_key=self.google_api_key)
            model = genai.GenerativeModel(
                model_name=os.getenv('LLM_MODEL', 'gemini-1.5-flash')
            )

            prompt = (
                "You are a helpful, conversational assistant for The Federal Polytechnic, Ado-Ekiti. "
                "Answer in a friendly and natural way. Use the provided institutional information when available, "
                "but do not invent exact details. If the exact answer is not in the provided data, politely say so and suggest checking the official website or the relevant office.\n\n"
                f"{context}"
            )

            response = model.generate_content(
                prompt,
                generation_config={
                    'temperature': float(os.getenv('TEMPERATURE', 0.7)),
                    'max_output_tokens': 500,
                }
            )

            return response.text.strip()

        except Exception as e:
            logger.error(f"Error with Gemini API: {str(e)}")
            return self._generate_with_template([], intent)

    def _generate_with_openai(self, query: str, context: str, intent: Dict) -> str:
        """
        Generate response using OpenAI API
        
        Args:
            query: User query
            context: Knowledge base context
            intent: Intent information
        
        Returns:
            Generated response
        """
        try:
            from openai import OpenAI

            client = OpenAI(api_key=self.openai_api_key)
            response = client.chat.completions.create(
                model=os.getenv('LLM_MODEL', 'gpt-3.5-turbo'),
                messages=[
                    {
                        "role": "system",
                        "content": """You are a helpful assistant for The Federal Polytechnic, Ado-Ekiti.
                        Provide accurate, concise responses based on the provided institutional information.
                        If information is not available, suggest contacting the relevant department."""
                    },
                    {
                        "role": "user",
                        "content": context
                    }
                ],
                temperature=float(os.getenv('TEMPERATURE', 0.7)),
                max_tokens=500
            )
            
            return (response.choices[0].message.content or '').strip()
            
        except Exception as e:
            logger.error(f"Error with OpenAI API: {str(e)}")
            return self._generate_with_template([], intent)
    
    def _generate_with_template(self, kb_entries: List[Dict], intent: Dict) -> str:
        """
        Generate response using template-based approach
        
        Args:
            kb_entries: Retrieved KB entries
            intent: Intent information
        
        Returns:
            Generated response
        """
        if not kb_entries:
            return f"""Thank you for your question about {intent.get('description', 'our services')}.
            I don't have specific information to answer this right now.
            Please contact the relevant department or visit the main campus for more details."""
        
        # Build response from KB entries
        response = f"Here's what I found about {intent.get('description', 'your question')}:\n\n"
        
        for entry in kb_entries[:3]:  # Use top 3 entries
            response += f"**Q: {entry.get('question', '')}**\n"
            response += f"{entry.get('answer', '')}\n\n"
        
        response += "If you need more information, please contact the relevant department or visit the campus."
        
        return response
    
    def _get_category_name(self, category_id: int) -> str:
        """Convert category ID to category name"""
        categories = {
            1: 'Admission',
            2: 'Course Registration',
            3: 'School Fees',
            4: 'Examination',
            5: 'Academic Calendar',
            6: 'Hostel Services',
            7: 'SIWES',
            8: 'Library Services',
            9: 'ICT Support',
            10: 'Transcript Services',
            11: 'Graduation Requirements'
        }
        return categories.get(category_id, 'General')
    
    def validate_response(self, response: str) -> bool:
        """
        Validate generated response quality
        
        Args:
            response: Generated response text
        
        Returns:
            True if response meets quality criteria
        """
        # Check minimum length
        if len(response) < 20:
            return False
        
        # Check for placeholder text or errors
        if 'error' in response.lower() or 'sorry' in response.lower():
            return True  # Still valid, just apologetic
        
        return True

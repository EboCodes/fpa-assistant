# AI-Powered Educational Service Assistant

An intelligent conversational platform for Nigerian tertiary institutions to provide students and stakeholders with 24/7 access to institutional administrative information.

**Case Study:** The Federal Polytechnic, Ado-Ekiti

---

## 🎯 Project Overview

This system uses AI, Natural Language Processing (NLP), and Large Language Models (LLMs) to:
- Answer student queries about admissions, fees, exams, registration, and more
- Provide information from a centralized knowledge base
- Reduce administrative workload
- Offer 24/7 availability

---

## 📁 Project Structure

```
educational-assistant/
├── frontend/                  # React + Vite Frontend
│   ├── src/
│   │   ├── components/       # React components
│   │   ├── pages/           # Page components
│   │   ├── styles/          # CSS/styling
│   │   ├── services/        # API calls
│   │   └── App.jsx
│   ├── package.json
│   └── vite.config.js
│
├── backend/                  # Node.js + Express Backend
│   ├── src/
│   │   ├── routes/          # API endpoints
│   │   ├── controllers/     # Business logic
│   │   ├── models/          # Database models
│   │   ├── middleware/      # Auth, validation
│   │   ├── services/        # AI/NLP services
│   │   └── server.js
│   ├── package.json
│   └── .env.example
│
├── ai-service/              # Python NLP Service
│   ├── src/
│   │   ├── nlp_processor.py       # NLP logic
│   │   ├── intent_recognizer.py   # Intent classification
│   │   ├── response_generator.py  # Generate responses
│   │   └── main.py               # Service entry
│   ├── requirements.txt
│   └── .env.example
│
├── database/
│   ├── schema/              # Database schema
│   │   └── initial_schema.sql
│   └── migrations/          # Database migrations
│
├── docs/                    # Documentation
│   ├── API.md              # API documentation
│   ├── SETUP.md            # Setup guide
│   └── ARCHITECTURE.md
│
├── .gitignore
├── docker-compose.yml      # Optional: containerized setup
└── README.md
```

---

## 🚀 Quick Start

### Prerequisites
- Node.js 16+ & npm
- Python 3.11+ (recommended; required by the supplied Docker image)
- PostgreSQL 12+
- Git

### Installation

1. **Clone & Setup**
```bash
cd educational-assistant
npm install  # Install root dependencies if any
```

2. **Frontend Setup**
```bash
cd frontend
npm install
npm run dev   # Starts on http://localhost:5173
```

3. **Backend Setup**
```bash
cd backend
npm install
cp .env.example .env  # Configure your database
npm run dev   # Starts on http://localhost:5000
```

4. **AI Service Setup**
```bash
cd ai-service
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
python src/main.py  # Starts on http://localhost:5001
```

5. **Database Setup**
```bash
psql -U postgres
CREATE DATABASE educational_assistant;
\c educational_assistant
\i database/schema/initial_schema.sql
```

---

## 📚 Knowledge Base System

The knowledge base stores all institutional information:

### Key Tables:
- **kb_entries** - Questions & answers
- **categories** - Service categories
- **keywords** - Search keywords
- **qa_pairs** - Q&A pairs for training

### Admin Features:
- Add/Edit/Delete entries
- Manage categories
- Update outdated information
- View analytics

---

## 🔌 API Endpoints

### Chat
- `POST /api/chat/message` - Send a query

### Admin
- `GET /api/admin/kb` - Get knowledge base
- `POST /api/admin/kb` - Add entry
- `PUT /api/admin/kb/:id` - Update entry
- `DELETE /api/admin/kb/:id` - Delete entry

### Categories
- `GET /api/categories` - Get all categories

---

## 🤖 AI Technologies

- **NLP:** spaCy, NLTK
- **LLM:** OpenAI API / Local LLMs
- **Intent Recognition:** Custom ML model
- **Embedding:** Sentence Transformers for semantic search

---

## 📖 Documentation

- [Setup Guide](docs/SETUP.md)
- [API Documentation](docs/API.md)
- [System Architecture](docs/ARCHITECTURE.md)

---

## 👨‍💻 Development

```bash
# Frontend development
cd frontend && npm run dev

# Backend development
cd backend && npm run dev

# AI service development
cd ai-service && python src/main.py
```

---

## 🔒 Security

- JWT authentication
- Encrypted passwords
- Rate limiting
- SQL injection prevention
- CORS protection

---

## 📝 License

This project is developed for The Federal Polytechnic, Ado-Ekiti.

---

## 👥 Contributors

- AJALA JOSHUA OLUWAFERANMI (FPA/CS/24/3-0089)

---

## 📧 Support

For issues or questions, contact: [your-email]

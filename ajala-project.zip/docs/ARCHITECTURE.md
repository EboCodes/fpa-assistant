# System Architecture

Complete technical architecture of the Educational Service Assistant.

---

## 🏗️ High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                                                                           │
│                         USER INTERFACE (Frontend)                        │
│                       React + Vite (Port 5173)                          │
│                                                                           │
│  ┌─────────────────────┐  ┌──────────────────┐  ┌──────────────────┐  │
│  │  Chat Interface     │  │  Category Filter │  │  Admin Dashboard │  │
│  │  - Input Box        │  │  - 11 Services   │  │  - KB Manager    │  │
│  │  - Message Display  │  │  - Quick Select  │  │  - User Analytics│  │
│  └─────────────────────┘  └──────────────────┘  └──────────────────┘  │
│                                                                           │
└──────────────────────────┬──────────────────────────────────────────────┘
                           │
                           │ HTTP/REST API
                           ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                                                                           │
│                    BACKEND API (Node.js + Express)                      │
│                         Port 5000                                        │
│                                                                           │
│  ┌─────────────────────────────────────────────────────────────────┐  │
│  │ Routes/Controllers:                                             │  │
│  │ - /api/chat         (chat operations)                          │  │
│  │ - /api/kb           (knowledge base queries)                   │  │
│  │ - /api/categories   (service categories)                       │  │
│  │ - /api/admin        (admin operations)                         │  │
│  │ - /api/analytics    (statistics & insights)                    │  │
│  └─────────────────────────────────────────────────────────────────┘  │
│                           ▼                          ▼                   │
│                    ┌──────────────┐         ┌──────────────────┐       │
│                    │  AI Service  │         │  PostgreSQL DB   │       │
│                    │  Integration │         │  Connection      │       │
│                    └──────────────┘         └──────────────────┘       │
│                           │                                             │
└───────────────────────────┼─────────────────────────────────────────────┘
                            │
                HTTP (JSON) │
                            ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                                                                           │
│            AI/NLP SERVICE (Python + Flask)                              │
│                  Port 5001                                              │
│                                                                           │
│  ┌──────────────────────────────────────────────────────────────────┐ │
│  │ Modules:                                                         │ │
│  │ ┌─────────────┐  ┌────────────────┐  ┌────────────────────┐   │ │
│  │ │  NLP        │  │  Intent        │  │  Response          │   │ │
│  │ │  Processor  │→ │  Recognizer    │→ │  Generator (LLM)   │   │ │
│  │ └─────────────┘  └────────────────┘  └────────────────────┘   │ │
│  │                                                                 │ │
│  │  • Tokenization      • Intent Classification      • OpenAI     │ │
│  │  • Lemmatization     • Confidence Scoring         • Template   │ │
│  │  • Embeddings        • Category Mapping           • Validation │ │
│  │  • Entity Extraction • KB Suggestions                          │ │
│  └──────────────────────────────────────────────────────────────────┘ │
│                                                                           │
└───────────────────────────┬─────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                                                                           │
│                    DATABASE (PostgreSQL)                                │
│                 Port 5432                                               │
│                                                                           │
│  ┌──────────────────────────────────────────────────────────────────┐ │
│  │ Tables:                                                          │ │
│  │ • users              • chat_messages      • embeddings          │ │
│  │ • categories         • conversations      • feedback             │ │
│  │ • knowledge_base     • analytics          • admin_logs           │ │
│  └──────────────────────────────────────────────────────────────────┘ │
│                                                                           │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 🗄️ Knowledge Base System

### Database Schema

#### 1. Knowledge Base Table (`knowledge_base`)

Core table storing Q&A pairs:

```sql
CREATE TABLE knowledge_base (
    id SERIAL PRIMARY KEY,
    category_id INT NOT NULL,          -- Links to categories
    question TEXT NOT NULL UNIQUE,      -- User-facing question
    answer TEXT NOT NULL,               -- Answer/information
    keywords VARCHAR(255),              -- Search keywords
    source VARCHAR(255),                -- Data source (office/document)
    status ENUM('active', 'inactive'),  -- Publication status
    created_by INT,                     -- Admin who created
    created_at TIMESTAMP,               -- Creation date
    updated_at TIMESTAMP                -- Last update
);
```

**Example Data:**
```
id: 1
category_id: 1 (Admission)
question: "What are the admission requirements for ND?"
answer: "To gain admission to ND programme..."
keywords: "admission,requirements,ND,JAMB,SSCE"
source: "Admission Office Official Guide"
status: "active"
```

#### 2. Categories Table (`categories`)

Defines the 11 service categories:

```sql
CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    icon VARCHAR(255)
);
```

**The 11 Categories:**
1. Admission
2. Course Registration
3. School Fees
4. Examination
5. Academic Calendar
6. Hostel Services
7. SIWES
8. Library Services
9. ICT Support
10. Transcript Services
11. Graduation Requirements

#### 3. Embeddings Table (`embeddings`)

Stores vector embeddings for semantic search:

```sql
CREATE TABLE embeddings (
    id SERIAL PRIMARY KEY,
    kb_id INT NOT NULL,
    question_embedding VECTOR(384),     -- Question embedding
    answer_embedding VECTOR(384),       -- Answer embedding
    created_at TIMESTAMP
);
```

#### 4. Chat Messages Table (`chat_messages`)

Logs all conversations:

```sql
CREATE TABLE chat_messages (
    id SERIAL PRIMARY KEY,
    conversation_id INT NOT NULL,
    user_message TEXT NOT NULL,
    ai_response TEXT NOT NULL,
    intent VARCHAR(100),                -- Recognized intent
    confidence_score FLOAT,             -- Confidence (0-1)
    kb_used INT                         -- KB entry reference
);
```

---

### Knowledge Base Population Strategies

#### Strategy 1: Manual Admin Entry (Recommended for Initial Setup)

**Flow:**
1. Admin logs into admin dashboard
2. Selects category
3. Fills in question, answer, keywords
4. Submits form
5. Backend validates and stores in DB
6. Embeddings generated automatically

**API Endpoint:**
```bash
POST /api/admin/kb
{
  "categoryId": 1,
  "question": "What are admission requirements?",
  "answer": "...",
  "keywords": "admission,requirements",
  "adminId": 1
}
```

#### Strategy 2: Bulk Import (CSV)

**Process:**
```
1. Prepare CSV file:
   category,question,answer,keywords,source
   Admission,"What is ND?","National Diploma is..","ND,diploma","Handbook"

2. Upload via admin interface
3. Parse and validate data
4. Batch insert into database
5. Generate embeddings in background
```

#### Strategy 3: Web Scraping

**For Future:** Automatically extract info from:
- Institution website
- PDF documents
- Official announcements
- Policy documents

---

### Retrieval-Augmented Generation (RAG) Workflow

**Flow Diagram:**
```
User Query
    │
    ▼
┌────────────────────┐
│ NLP Processing     │  - Tokenization
│ & Embedding        │  - Lemmatization
│                    │  - Generate embedding vector
└────────────────────┘
    │
    ▼
┌────────────────────┐
│ Similarity Search  │  - Compare with KB embeddings
│ (Vector DB)        │  - Cosine similarity calculation
│                    │  - Return top 3-5 matches
└────────────────────┘
    │
    ▼
┌────────────────────┐
│ Build Context      │  - Combine matched Q&A
│                    │  - Add intent info
│                    │  - Format for LLM
└────────────────────┘
    │
    ▼
┌────────────────────┐
│ Generate Response  │  - OpenAI API call
│ with LLM           │  - Use context as prompt
│                    │  - Generate natural response
└────────────────────┘
    │
    ▼
AI Response to User
```

**Python Code Example:**
```python
# 1. Process query
query_embedding = nlp_processor.get_embeddings(user_query)

# 2. Find similar KB entries
similar_entries = db.query("""
    SELECT kb.*, embeddings.question_embedding
    FROM knowledge_base kb
    JOIN embeddings ON kb.id = embeddings.kb_id
    WHERE kb.status = 'active'
    ORDER BY similarity(embeddings.question_embedding, %s) DESC
    LIMIT 5
""", query_embedding)

# 3. Build prompt
context = "\n".join([
    f"Q: {entry['question']}\nA: {entry['answer']}"
    for entry in similar_entries
])

# 4. Call LLM
response = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": f"{context}\n\nUser: {user_query}"}
    ]
)
```

---

## 🤖 Intent Recognition System

### Intent Categories (11 total, matching service categories)

```python
{
    'admission': {
        'keywords': ['admission', 'apply', 'requirements'],
        'category_id': 1
    },
    'course_registration': {
        'keywords': ['course', 'registration', 'register'],
        'category_id': 2
    },
    # ... 9 more categories
}
```

### Intent Recognition Flow

```
User Message
    │
    ▼
Keyword Matching
    │
    ├─→ Extract words
    │
    ├─→ Match against intent keywords
    │
    ├─→ Calculate scores
    │
    └─→ Normalize confidence (0-1)
        │
        ▼
Return Intent:
{
  "name": "admission",
  "confidence": 0.95,
  "category_id": 1,
  "suggestions": [
    {"name": "course_registration", "confidence": 0.15}
  ]
}
```

---

## 🔄 Data Flow: Complete Chat Example

### Scenario: Student asks "How do I register my courses?"

```
STEP 1: Frontend
  └─ User types: "How do I register my courses?"
  └─ Sends to backend: POST /api/chat/message

STEP 2: Backend
  └─ Receives message
  └─ Forwards to AI Service: POST /api/process
  └─ Creates conversation record

STEP 3: AI Service - NLP Processing
  └─ Process: "how do i register my courses"
  └─ Clean: "register courses"
  └─ Lemmatize: "register course"
  └─ Generate embeddings

STEP 4: AI Service - Intent Recognition
  └─ Check keywords
  └─ Match: course_registration (confidence: 0.92)
  └─ Category: 2 (Course Registration)

STEP 5: AI Service - KB Retrieval
  └─ Query: SELECT FROM knowledge_base WHERE category_id = 2
  └─ Get all Course Registration entries
  └─ Similarity search with embeddings
  └─ Return top 3 matches

STEP 6: AI Service - Response Generation
  └─ Build context from matched entries
  └─ Call OpenAI API with context
  └─ Generate natural response
  └─ Validate response quality

STEP 7: Backend
  └─ Receives response from AI Service
  └─ Saves to chat_messages table
  └─ Updates analytics
  └─ Returns to frontend

STEP 8: Frontend
  └─ Displays response to user
  └─ Shows source KB entry
  └─ Allows feedback (helpful/not helpful)

STEP 9: Backend
  └─ Saves user feedback
  └─ Updates analytics
  └─ Logs interaction for analysis
```

---

## 📊 Database Relationships

```
┌───────────────┐
│   users       │
│───────────────│
│ id (PK)       │
│ name          │
│ email         │
│ role          │
└───────────────┘
       │
       │ 1:N
       │
   ┌───┴─────────────────────────┐
   │                             │
   ▼                             ▼
┌────────────────┐        ┌─────────────────┐
│ conversations  │        │ knowledge_base  │
│────────────────│        │─────────────────│
│ id (PK)        │        │ id (PK)         │
│ user_id (FK)   │        │ category_id(FK) │
│ title          │        │ created_by (FK) │
│ created_at     │        │ question        │
└────────────────┘        │ answer          │
       │                  │ keywords        │
       │ 1:N              │ status          │
       │                  └─────────────────┘
       │                         │
       ▼                         │ 1:N
┌──────────────────┐            │
│ chat_messages    │            │
│──────────────────│            ▼
│ id (PK)          │      ┌────────────────┐
│ conversation(FK) │      │ embeddings     │
│ kb_used (FK)────┼──────→│────────────────│
│ user_message    │       │ kb_id (FK)     │
│ ai_response     │       │ embeddings     │
│ intent          │       └────────────────┘
│ confidence      │
└──────────────────┘
```

---

## 🔐 Admin Management System

### Admin Operations

**Create KB Entry:**
```javascript
POST /api/admin/kb
{
  "categoryId": 1,
  "question": "...",
  "answer": "...",
  "keywords": "..."
}
```

**Update KB Entry:**
```javascript
PUT /api/admin/kb/1
{
  "question": "...",
  "answer": "...",
  "status": "active|inactive|archived"
}
```

**Delete KB Entry:**
```javascript
DELETE /api/admin/kb/1
```

**View Analytics:**
```javascript
GET /api/admin/analytics
```

---

## 🚀 Scaling Strategies

### 1. Database Optimization
- Index frequently queried fields
- Partition KB by category
- Archive old conversations
- Cache popular entries

### 2. Caching Layer
```
Frontend Cache (Local Storage)
    ↓
Redis Cache (Categories, Popular KB)
    ↓
Database (Primary source)
```

### 3. Load Balancing
```
Multiple Backend Instances
    ↓
Load Balancer (nginx)
    ↓
Shared Database (PostgreSQL)
```

### 4. Microservices
- Separate AI service (already done)
- Separate analytics service
- Separate admin service
- Independent scaling

---

## 🔒 Security Architecture

### Authentication Flow
```
User Login
    ↓
Verify Credentials
    ↓
Generate JWT Token
    ↓
Include in Authorization Header
    ↓
Protected Routes Verify Token
```

### Database Security
- Parameterized queries (prevent SQL injection)
- Encrypted passwords (bcrypt)
- Connection pooling
- Regular backups

### API Security
- CORS protection
- Rate limiting
- Input validation
- SQL injection prevention

---

## 📈 Performance Metrics

### Expected Performance
- Query response: < 1 second
- Chat response: 2-5 seconds (including AI processing)
- Page load: < 2 seconds
- Database queries: < 100ms

### Monitoring Points
- API response times
- Database query performance
- AI Service latency
- User engagement metrics
- Error rates

---

## 🧪 Testing Architecture

### Unit Tests
- NLP processing functions
- Intent recognition accuracy
- API endpoint validation

### Integration Tests
- End-to-end chat flow
- Database operations
- API communications

### Performance Tests
- Load testing (concurrent users)
- Response time benchmarking
- Database scalability

---

## 📋 Deployment Architecture

### Development
```
Local Machines
- Frontend (localhost:5173)
- Backend (localhost:5000)
- AI Service (localhost:5001)
- Database (localhost:5432)
```

### Production
```
Cloud Infrastructure (AWS/Azure/GCP)
├── Frontend (CDN + Static Hosting)
├── Backend (Container + Auto-scaling)
├── AI Service (Serverless / Container)
└── Database (Managed PostgreSQL)
```

---

## 🔄 Continuous Integration/Deployment

```
GitHub/GitLab
    ↓
Automated Tests
    ↓
Build Containers
    ↓
Push to Registry
    ↓
Deploy to Staging
    ↓
Smoke Tests
    ↓
Deploy to Production
```

---

## 📚 Technology Stack Summary

| Component | Technology | Purpose |
|-----------|-----------|---------|
| Frontend | React + Vite | Modern UI framework |
| Backend | Node.js + Express | API server |
| Database | PostgreSQL | Data storage |
| NLP | spaCy + NLTK | Text processing |
| Embeddings | Sentence-Transformers | Semantic search |
| LLM | OpenAI API | Response generation |
| Caching | Redis (optional) | Performance |
| Deployment | Docker | Containerization |

---

## 🎯 Future Enhancements

1. **Multi-language Support**
   - Translate KB to Yoruba, Hausa
   - Language detection
   - Multilingual embeddings

2. **Advanced Analytics**
   - User satisfaction tracking
   - Query patterns analysis
   - Improvement recommendations

3. **Mobile App**
   - React Native / Flutter
   - Offline mode
   - Push notifications

4. **Advanced Features**
   - Voice input/output
   - Document upload
   - Scheduled notifications
   - Integration with institution systems

---

## 📞 System Integration Points

```
Educational System
    ├─ Student Portal (SSO login)
    ├─ Email System (notifications)
    ├─ Document Repository (PDF access)
    └─ Analytics Platform (user insights)
```

---

## ✅ Architecture Review Checklist

- [ ] Database schema optimized
- [ ] All 11 categories defined
- [ ] Sample KB entries created
- [ ] NLP pipeline tested
- [ ] Intent recognition accurate
- [ ] Embeddings generated
- [ ] LLM integration working
- [ ] Admin interface functional
- [ ] Error handling implemented
- [ ] Logging/monitoring in place
- [ ] Security measures active
- [ ] Performance benchmarked
- [ ] Documentation complete

# Setup Guide

Complete setup instructions for the AI-Powered Educational Service Assistant.

---

## 📋 Prerequisites

- **Node.js** 16+ with npm
- **Python** 3.11+ with pip
- **PostgreSQL** 12+ (running)
- **Git** (optional)

### Check Installations

```bash
node --version      # Should be 16+
npm --version       # Should be 8+
python --version    # Should be 3.8+
psql --version      # Should be 12+
```

---

## 🗄️ Database Setup

### 1. Create Database

```bash
# Connect to PostgreSQL as admin
psql -U postgres

# Create database
CREATE DATABASE educational_assistant;

# Connect to new database
\c educational_assistant

# Run schema
\i database/schema/initial_schema.sql

# Verify tables
\dt
```

### 2. Verify Tables (You should see):
- `users`
- `categories`
- `knowledge_base`
- `embeddings`
- `conversations`
- `chat_messages`
- `feedback`
- `analytics`
- `admin_logs`

---

## 🎨 Frontend Setup

### 1. Navigate to Frontend Directory

```bash
cd frontend
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Start Development Server

```bash
npm run dev
```

**Output should show:**
```
  VITE v5.0.0  ready in 100 ms

  ➜  Local:   http://localhost:5173/
  ➜  press h to show help
```

Access: **http://localhost:5173**

---

## 🔌 Backend Setup

### 1. Navigate to Backend Directory

```bash
cd backend
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Create Environment File

```bash
cp .env.example .env
```

### 4. Configure Database Connection

Edit `backend/.env`:
```
DATABASE_URL=postgresql://postgres:password@localhost:5432/educational_assistant
JWT_SECRET=your_secret_key_here
LLM_PROVIDER=gemini
GOOGLE_API_KEY=your_google_api_key
LLM_MODEL=gemini-1.5-flash
```

If you prefer OpenAI instead, use:
```
LLM_PROVIDER=openai
OPENAI_API_KEY=your_openai_key
LLM_MODEL=gpt-3.5-turbo
```

### 5. Start Development Server

```bash
npm run dev
```

**Output should show:**
```
✅ Database connected successfully
🚀 Backend server running on http://localhost:5000
📊 Health check: http://localhost:5000/health
```

### 6. Test Backend

```bash
curl http://localhost:5000/health
```

Response:
```json
{
  "status": "API is running",
  "timestamp": "2024-..."
}
```

---

## 🤖 AI Service Setup

### 1. Navigate to AI Service Directory

```bash
cd ai-service
```

### 2. Create Python Virtual Environment

```bash
# Linux/Mac
python3 -m venv venv
source venv/bin/activate

# Windows
python -m venv venv
venv\Scripts\activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

**This will take a few minutes** - installing spaCy, transformers, and sentence-transformers.

### 4. Create Environment File

```bash
cp .env.example .env
```

### 5. Download spaCy Model (Required)

```bash
python -m spacy download en_core_web_sm
```

### 6. Start AI Service

```bash
python src/main.py
```

**Output should show:**
```
✅ NLP Processor initialized
✅ Intent Recognizer initialized
✅ Response Generator initialized
🚀 AI Service starting on http://localhost:5001
```

### 7. Test AI Service

```bash
curl -X POST http://localhost:5001/health
```

Response:
```json
{
  "status": "AI Service is running",
  "version": "1.0.0"
}
```

---

## 🧪 Testing the Full System

### 1. Ensure All Services Running

```
Frontend: http://localhost:5173 ✅
Backend:  http://localhost:5000 ✅
AI:       http://localhost:5001 ✅
Database: PostgreSQL running ✅
```

### 2. Test Chat Flow

1. Open http://localhost:5173 in browser
2. Select a category (e.g., "Admission")
3. Type a question: "What are admission requirements?"
4. System should:
   - Process your message
   - Retrieve KB entries
   - Generate response using AI
   - Display in chat

### 3. Test API Endpoints

```bash
# Get categories
curl http://localhost:5000/api/categories

# Get knowledge base
curl http://localhost:5000/api/kb

# Send message (requires user ID)
curl -X POST http://localhost:5000/api/chat/message \
  -H "Content-Type: application/json" \
  -d '{"message":"What are the admission requirements?"}'
```

---

## 🔐 Admin Dashboard Setup

### 1. Create Admin User (in database)

```sql
INSERT INTO users (name, email, password, role) VALUES (
    'Admin User',
    'admin@fedpolyado.edu.ng',
    'bcrypt_hashed_password',  -- Use bcrypt to hash password
    'admin'
);
```

### 2. Admin APIs

```bash
# Get all KB entries
curl http://localhost:5000/api/admin/kb

# Add new KB entry
curl -X POST http://localhost:5000/api/admin/kb \
  -H "Content-Type: application/json" \
  -d '{
    "categoryId": 1,
    "question": "What is admission?",
    "answer": "Admission is...",
    "keywords": "admission,apply,enroll",
    "adminId": 1
  }'

# Update KB entry
curl -X PUT http://localhost:5000/api/admin/kb/1 \
  -H "Content-Type: application/json" \
  -d '{
    "question": "Updated question",
    "answer": "Updated answer",
    "status": "active",
    "adminId": 1
  }'

# Delete KB entry
curl -X DELETE http://localhost:5000/api/admin/kb/1
```

---

## 📚 Knowledge Base Management

### Adding Knowledge Base Entries

The knowledge base is the core of the system. Add entries for:

1. **Admission (Category 1)**
   - Admission requirements
   - Application process
   - Entry requirements by program

2. **Course Registration (Category 2)**
   - How to register courses
   - Registration deadlines
   - Course requirements

3. **School Fees (Category 3)**
   - Fee schedules
   - Payment procedures
   - Payment channels

4. **And so on for all 11 categories...**

### Database Structure

```
Knowledge Base (kb_entries):
├── id: Unique identifier
├── category_id: Links to category
├── question: User-facing question
├── answer: The answer/information
├── keywords: Search keywords
├── status: active/inactive/archived
├── created_at: Creation timestamp
└── updated_at: Last update timestamp
```

---

## 🚀 Production Deployment

### 1. Build Frontend

```bash
cd frontend
npm run build  # Creates dist/ folder
```

### 2. Environment Variables

Update all `.env` files for production:
- Set `NODE_ENV=production`
- Use real database credentials
- Set strong JWT secrets
- Configure CORS properly

### 3. Deploy with Docker

```bash
# Build and run all services
docker-compose up -d
```

### 4. Deploy Separately

Each service can be deployed independently:
- Frontend: Static files to CDN/web server
- Backend: Node.js hosting (Heroku, AWS, etc.)
- AI Service: Python hosting (AWS Lambda, Heroku, etc.)
- Database: Managed PostgreSQL (AWS RDS, etc.)

---

## 🐛 Troubleshooting

### Database Connection Error

```
❌ Database connection failed: connect ECONNREFUSED 127.0.0.1:5432
```

**Solution:**
```bash
# Start PostgreSQL (Mac with Homebrew)
brew services start postgresql

# Or check if running
psql -U postgres -d educational_assistant
```

### Frontend Proxy Error

**Solution:** Ensure backend is running on port 5000
```bash
lsof -i :5000  # Check if port is in use
```

### Python Virtual Environment Issues

```bash
# Recreate venv
rm -rf ai-service/venv
python3 -m venv ai-service/venv
source ai-service/venv/bin/activate
pip install -r ai-service/requirements.txt
```

### Module Not Found Errors

```bash
# Reinstall all dependencies
pip install --upgrade --force-reinstall -r requirements.txt
```

---

## 📊 Development Tips

### Enable Debug Mode

```bash
# Backend
NODE_ENV=development npm run dev

# AI Service
DEBUG=True python src/main.py
```

### View Database

```bash
psql -U postgres -d educational_assistant

# List tables
\dt

# Show table structure
\d knowledge_base

# Query data
SELECT * FROM categories;
```

### Monitor Services

**Terminal 1:** Frontend
```bash
cd frontend && npm run dev
```

**Terminal 2:** Backend
```bash
cd backend && npm run dev
```

**Terminal 3:** AI Service
```bash
cd ai-service && source venv/bin/activate && python src/main.py
```

---

## ✅ Setup Checklist

- [ ] PostgreSQL installed and running
- [ ] Database created
- [ ] Frontend dependencies installed
- [ ] Backend dependencies installed
- [ ] Backend `.env` configured
- [ ] AI Service venv created
- [ ] AI Service dependencies installed
- [ ] spaCy model downloaded
- [ ] All three services running on correct ports
- [ ] APIs responding to test requests
- [ ] Chat flow working end-to-end
- [ ] Knowledge base populated with sample data

---

## 🎯 Next Steps

1. **Add Institution Data**: Populate KB with real institutional information
2. **Customize UI**: Modify frontend styling for your institution
3. **Configure LLM**: Set up OpenAI or alternative LLM
4. **Add Authentication**: Implement JWT-based authentication
5. **Deploy**: Move to production hosting

---

## 📧 Support

For issues or questions, refer to:
- Backend docs: [API.md](API.md)
- Architecture: [ARCHITECTURE.md](ARCHITECTURE.md)
- Code: See inline comments in source files

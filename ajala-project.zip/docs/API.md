# API Documentation

Complete API reference for the Educational Service Assistant.

---

## 📡 Base URLs

- **Frontend:** http://localhost:5173
- **Backend API:** http://localhost:5000
- **AI Service:** http://localhost:5001

---

## 🔐 Authentication

Currently uses bearer token (JWT). Future versions will implement:

```
Authorization: Bearer <token>
```

---

## 🛣️ Backend API Endpoints

### Health Check

**GET** `/health`

Check if backend is running.

**Response (200):**
```json
{
  "status": "API is running",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

---

### 💬 Chat Endpoints

#### Send Message

**POST** `/api/chat/message`

Send a user message and get AI response.

**Request Body:**
```json
{
  "userId": 1,
  "conversationId": "conv_123",
  "message": "What are the admission requirements?"
}
```

**Response (200):**
```json
{
  "success": true,
  "conversationId": "conv_123",
  "message": "Message received and being processed"
}
```

**Error (400):**
```json
{
  "error": "Message cannot be empty"
}
```

---

#### Get Conversations

**GET** `/api/conversations/:userId`

Retrieve all conversations for a user.

**Response (200):**
```json
{
  "success": true,
  "conversations": [
    {
      "id": 1,
      "user_id": 1,
      "title": "Admission Queries",
      "created_at": "2024-01-15T10:00:00Z",
      "updated_at": "2024-01-15T10:30:00Z"
    }
  ]
}
```

---

### 📚 Knowledge Base Endpoints

#### Get All KB Entries

**GET** `/api/kb`

Retrieve knowledge base entries (public access).

**Query Parameters:**
- `category` (optional): Filter by category name

**Response (200):**
```json
{
  "success": true,
  "count": 50,
  "data": [
    {
      "id": 1,
      "category_id": 1,
      "category_name": "Admission",
      "question": "What are the admission requirements?",
      "answer": "To gain admission...",
      "keywords": "admission,requirements,ND",
      "source": "Admission Office",
      "status": "active",
      "created_at": "2024-01-15T09:00:00Z",
      "updated_at": "2024-01-15T09:00:00Z"
    }
  ]
}
```

**Example Requests:**
```bash
# Get all entries
curl http://localhost:5000/api/kb

# Filter by category
curl http://localhost:5000/api/kb?category=Admission
```

---

### 📂 Category Endpoints

#### Get All Categories

**GET** `/api/categories`

Retrieve all service categories.

**Response (200):**
```json
{
  "success": true,
  "categories": [
    {
      "id": 1,
      "name": "Admission",
      "description": "Admission requirements, procedures, and guidelines",
      "icon": "admission-icon",
      "created_at": "2024-01-15T09:00:00Z"
    },
    {
      "id": 2,
      "name": "Course Registration",
      "description": "Course registration procedures and deadlines",
      "icon": "registration-icon",
      "created_at": "2024-01-15T09:00:00Z"
    }
  ]
}
```

**All 11 Categories:**
1. Admission
2. Course Registration
3. School Fees
4. Examination
5. Academic Calendar
6. Hostel Services
7. SIWES
8. Library Services
9. ICT Support
10. Transcript Services
11. Graduation Requirements

---

## 🔧 Admin API Endpoints

### Knowledge Base Management

#### Get All KB Entries (Admin)

**GET** `/api/admin/kb`

**Headers:**
```
Authorization: Bearer <admin_token>
```

**Response:** (Same as public /api/kb)

---

#### Add KB Entry

**POST** `/api/admin/kb`

Create a new knowledge base entry.

**Headers:**
```
Authorization: Bearer <admin_token>
Content-Type: application/json
```

**Request Body:**
```json
{
  "categoryId": 1,
  "question": "What is the minimum JAMB score for admission?",
  "answer": "The minimum JAMB score is 120 points. However, specific programs may have higher requirements.",
  "keywords": "JAMB,score,admission,120",
  "adminId": 1
}
```

**Response (201):**
```json
{
  "success": true,
  "data": {
    "id": 101,
    "category_id": 1,
    "question": "What is the minimum JAMB score for admission?",
    "answer": "The minimum JAMB score is 120 points...",
    "keywords": "JAMB,score,admission,120",
    "created_by": 1,
    "status": "active",
    "created_at": "2024-01-15T10:30:00Z",
    "updated_at": "2024-01-15T10:30:00Z"
  }
}
```

**Error (500):**
```json
{
  "error": "Failed to create knowledge base entry"
}
```

---

#### Update KB Entry

**PUT** `/api/admin/kb/:id`

Update an existing knowledge base entry.

**Headers:**
```
Authorization: Bearer <admin_token>
Content-Type: application/json
```

**Request Body:**
```json
{
  "question": "What is the minimum JAMB score for admission (Updated)?",
  "answer": "The minimum JAMB score is 120 points...",
  "keywords": "JAMB,score,admission,minimum",
  "status": "active",
  "adminId": 1
}
```

**Response (200):**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "category_id": 1,
    "question": "What is the minimum JAMB score for admission (Updated)?",
    "answer": "The minimum JAMB score is 120 points...",
    "status": "active",
    "updated_at": "2024-01-15T10:45:00Z"
  }
}
```

---

#### Delete KB Entry

**DELETE** `/api/admin/kb/:id`

Delete a knowledge base entry.

**Headers:**
```
Authorization: Bearer <admin_token>
```

**Response (200):**
```json
{
  "success": true,
  "message": "Knowledge base entry deleted"
}
```

---

### Analytics

#### Get Analytics

**GET** `/api/admin/analytics`

Retrieve system analytics for today.

**Response (200):**
```json
{
  "success": true,
  "analytics": {
    "id": 1,
    "total_queries": 150,
    "total_users": 45,
    "average_response_time": 1.23,
    "queries_resolved": 142,
    "date": "2024-01-15",
    "created_at": "2024-01-15T10:00:00Z"
  }
}
```

---

## 🤖 AI Service API Endpoints

### Health Check

**GET** `/health`

Check if AI service is running.

**Response (200):**
```json
{
  "status": "AI Service is running",
  "version": "1.0.0"
}
```

---

### Message Processing

#### Process Message

**POST** `/api/process`

Process a user message with NLP and generate response.

**Request Body:**
```json
{
  "message": "What are the admission requirements?",
  "conversationId": "conv_123",
  "context": {}
}
```

**Response (200):**
```json
{
  "success": true,
  "conversationId": "conv_123",
  "original_message": "What are the admission requirements?",
  "processed_message": "admission requirement",
  "intent": "admission",
  "confidence": 0.95,
  "response": "To gain admission into the ND programme...",
  "suggested_kb_entries": [
    {
      "id": 1,
      "question": "What are the admission requirements?",
      "answer": "..."
    }
  ]
}
```

---

#### Recognize Intent

**POST** `/api/intent` or **POST** `/api/process`

Identify user intent from message and generate contextual response.

**Request Body:**
```json
{
  "message": "Where is the school located?"
}
```

**Response (200):**
```json
{
  "success": true,
  "original_message": "Where is the school located?",
  "processed_message": "school located",
  "intent": "school_location",
  "confidence": 0.96,
  "response": "Hello! The Federal Polytechnic is located in Ado-Ekiti, Ekiti State, Nigeria.",
  "suggested_kb_entries": []
}
```

**Supported Intents (with confidence thresholds):**

| Intent | Keywords | Confidence | Example |
|--------|----------|-----------|---------|
| `school_location` | where, location, address, campus, located | 0.85+ | "Where is the school located?" |
| `admission` | admission, apply, requirements, JAMB, entrance | 0.80+ | "What are admission requirements?" |
| `course_registration` | register, courses, course registration, enroll | 0.85+ | "How do I register my courses?" |
| `fees` | fees, payment, tuition, cost, charges | 0.85+ | "What are school fees?" |
| `examination` | exam, examination, test, results, grading | 0.80+ | "When is the exam scheduled?" |
| `academic_calendar` | calendar, academic, semester, session, dates | 0.80+ | "What is the academic calendar?" |
| `hostel` | hostel, accommodation, lodging, rooms | 0.85+ | "How do I apply for hostel?" |
| `siwes` | SIWES, industrial training, attachment, placement | 0.85+ | "What is SIWES?" |
| `library` | library, books, research, borrowing, resources | 0.80+ | "How do I access library services?" |
| `ict_support` | ICT, computer, technical, password, email | 0.85+ | "How do I reset my email password?" |
| `transcript` | transcript, results, grades, certification, document | 0.85+ | "How do I request my transcript?" |
| `graduation` | graduation, convocation, degree, diploma, certificate | 0.85+ | "What are graduation requirements?" |

**Intent Recognition Features:**
- Word boundary matching to prevent false positives (e.g., "school" in "fees" query)
- Context-aware scoring with keyword frequency analysis
- Early detection for high-confidence matches
- Fallback to general knowledge if KB doesn't have exact match
- Conversational responses powered by Gemini AI

**Example Requests & Responses:**

**1. Location Query:**
```bash
curl -X POST http://localhost:5001/api/process \
  -H 'Content-Type: application/json' \
  -d '{"message":"Where is the school located?"}'
```

Response:
```json
{
  "success": true,
  "intent": "school_location",
  "confidence": 0.96,
  "response": "Federal Polytechnic Ado-Ekiti is located in Ado-Ekiti, Ekiti State, Nigeria..."
}
```

**2. Admission Query:**
```bash
curl -X POST http://localhost:5001/api/process \
  -H 'Content-Type: application/json' \
  -d '{"message":"What are the admission requirements?"}'
```

Response:
```json
{
  "success": true,
  "intent": "admission",
  "confidence": 0.94,
  "response": "To gain admission to an ND programme, you must have: 1) O-Level credits... 2) JAMB score of 120+... 3) Pass Post-UTME..."
}
```

**3. Out-of-KB Query (Graceful Fallback):**
```bash
curl -X POST http://localhost:5001/api/process \
  -H 'Content-Type: application/json' \
  -d '{"message":"Can I transfer to another institution?"}'
```

Response:
```json
{
  "success": true,
  "intent": "unknown",
  "confidence": 0.35,
  "response": "I don't have specific information about transfer policies in my knowledge base. I recommend contacting the Student Affairs Office or visiting the official website for this information."
}
```

---

### Semantic Search

#### Get Embeddings

**POST** `/api/embeddings`

Generate embeddings for texts (for semantic search).

**Request Body:**
```json
{
  "texts": [
    "What are admission requirements?",
    "How do I register courses?"
  ]
}
```

**Response (200):**
```json
{
  "success": true,
  "embeddings": [
    [0.123, -0.456, 0.789, ...],  // 384-dimensional vector
    [-0.234, 0.567, -0.890, ...]
  ]
}
```

---

#### Calculate Similarity

**POST** `/api/similarity`

Find similar KB entries for a query (retrieval-augmented generation).

**Request Body:**
```json
{
  "query": "What are the admission requirements?",
  "kb_entries": [
    {
      "id": 1,
      "question": "What are the admission requirements?",
      "answer": "To gain admission..."
    },
    {
      "id": 2,
      "question": "How do I apply for admission?",
      "answer": "To apply for admission..."
    }
  ]
}
```

**Response (200):**
```json
{
  "success": true,
  "query": "What are the admission requirements?",
  "results": [
    {
      "id": 1,
      "question": "What are the admission requirements?",
      "answer": "To gain admission...",
      "similarity_score": 0.98
    },
    {
      "id": 2,
      "question": "How do I apply for admission?",
      "answer": "To apply for admission...",
      "similarity_score": 0.75
    }
  ]
}
```

---

## 🔄 Request/Response Format

### Standard Success Response

```json
{
  "success": true,
  "data": { /* ... */ }
}
```

### Standard Error Response

```json
{
  "error": "Error description",
  "code": "ERROR_CODE"
}
```

### HTTP Status Codes

| Code | Meaning | Example |
|------|---------|---------|
| 200 | Success | GET request successful |
| 201 | Created | POST created new resource |
| 400 | Bad Request | Missing required field |
| 401 | Unauthorized | Invalid token |
| 404 | Not Found | Resource doesn't exist |
| 500 | Server Error | Database connection failed |

---

## 📊 Data Models

### User
```json
{
  "id": 1,
  "name": "John Doe",
  "email": "john@fedpolyado.edu.ng",
  "role": "student",
  "created_at": "2024-01-15T09:00:00Z"
}
```

### Knowledge Base Entry
```json
{
  "id": 1,
  "category_id": 1,
  "question": "What are the admission requirements?",
  "answer": "To gain admission...",
  "keywords": "admission,requirements,JAMB",
  "source": "Admission Office",
  "status": "active",
  "created_at": "2024-01-15T09:00:00Z"
}
```

### Chat Message
```json
{
  "id": 1,
  "conversation_id": 1,
  "user_message": "What are admission requirements?",
  "ai_response": "To gain admission...",
  "intent": "admission",
  "confidence_score": 0.95,
  "kb_used": 1,
  "created_at": "2024-01-15T10:30:00Z"
}
```

---

## 🧪 Example Workflows

### Complete Chat Flow

1. **User sends message**
   ```bash
   POST /api/chat/message
   {"message": "What are the admission requirements?"}
   ```

2. **Backend routes to AI Service**
   ```bash
   POST /api/process
   {"message": "What are the admission requirements?"}
   ```

3. **AI Service:**
   - Processes NLP
   - Recognizes intent: "admission"
   - Requests KB retrieval

4. **Backend retrieves KB**
   ```bash
   GET /api/kb?category=Admission
   ```

5. **AI Service generates response**
   - Uses LLM or template
   - Returns response

6. **Response sent to user**
   - Displayed in chat
   - Saved to database

---

## 🔒 Security Considerations

1. **API Keys:** Store in .env files, never commit
2. **Database:** Use strong passwords, enable authentication
3. **CORS:** Configure for production domain only
4. **Rate Limiting:** Implement per IP/user (future)
5. **Input Validation:** All inputs validated server-side
6. **SQL Injection:** Using parameterized queries (pg-promise)

---

## 📈 Rate Limits (Future)

- Chat messages: 100/hour per user
- API requests: 1000/hour per IP
- Admin operations: 500/hour per admin

---

## 🚀 Performance Tips

1. Cache KB entries in frontend
2. Use pagination for large datasets
3. Index frequently queried fields
4. Batch admin operations
5. Monitor database query performance

---

## 📚 Related Documentation

- [Setup Guide](SETUP.md)
- [System Architecture](ARCHITECTURE.md)
- Code comments in source files

---

## 🆘 Troubleshooting

### 500 Error on /api/chat/message

**Check:**
- Is database running?
- Are all services started?
- Check backend logs

### Empty Response

**Check:**
- Is AI service running?
- Is knowledge base populated?
- Check network requests in browser dev tools

### CORS Errors

**Fix:**
- Ensure CORS configured in backend
- Check CLIENT_URL in .env matches frontend URL

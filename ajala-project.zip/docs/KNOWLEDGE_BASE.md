# Knowledge Base Implementation Guide

Complete guide to building, populating, and managing the knowledge base for the Educational Service Assistant.

---

## 📚 What is the Knowledge Base?

The knowledge base is the **brain** of the AI Assistant. It contains all the institutional information that the system uses to answer student questions. Without a good knowledge base, the AI cannot provide accurate responses.

**Example KB Entry:**
```
Question: "What are the admission requirements for ND programmes?"
Answer: "To gain admission to an ND programme at The Federal Polytechnic, 
Ado-Ekiti, you must have:
1. O-Level (SSCE/WAEC/NECO) with at least 5 credits
2. JAMB score of minimum 120 points
3. Pass the Post-UTME screening exercise
For specific subject requirements, contact the Admission Office."

Keywords: "admission,requirements,ND,JAMB,entrance"
Source: "Admission Office Official Guide"
Category: "Admission"
```

---

## 🏗️ Knowledge Base Architecture

### Storage

**Database Table: `knowledge_base`**

```sql
Column Name         | Type      | Purpose
───────────────────┼───────────┼─────────────────────────────
id                 | INTEGER   | Unique identifier
category_id        | INTEGER   | Links to 11 service categories
question           | TEXT      | User-facing question
answer             | TEXT      | Answer/information provided
keywords           | VARCHAR   | Search keywords (comma-separated)
source             | VARCHAR   | Where info came from
status             | ENUM      | active/inactive/archived
created_by         | INTEGER   | Admin who created entry
created_at         | TIMESTAMP | Creation date
updated_at         | TIMESTAMP | Last modification date
```

### Semantic Search (Embeddings)

**Database Table: `embeddings`**

```sql
Column Name         | Type      | Purpose
───────────────────┼───────────┼─────────────────────────────
id                 | INTEGER   | Unique identifier
kb_id              | INTEGER   | Foreign key to knowledge_base
question_embedding | VECTOR    | 384-dimensional embedding of question
answer_embedding   | VECTOR    | 384-dimensional embedding of answer
created_at         | TIMESTAMP | Creation date
```

**What are Embeddings?**
- Embeddings convert text into mathematical vectors (lists of numbers)
- Similar texts have similar embeddings
- Allows semantic search (understanding meaning, not just keywords)
- Generated automatically when KB entries are created

**Example:**
```
Question: "How do I register for courses?"
Embedding: [0.123, -0.456, 0.789, ..., 0.234]  # 384 numbers

Question: "What's the procedure to register courses?"
Embedding: [0.125, -0.450, 0.785, ..., 0.235]  # Similar!

Similarity Score: 0.98 (very similar)
```

---

## 📝 The 11 Service Categories

Each category represents a major institutional service. The KB entries are organized by these:

### 1. **Admission** (Category ID: 1)
- Admission requirements
- Application procedures
- Entry requirements by program
- Entrance exam details
- Application deadlines

**Sample Questions:**
- What are the admission requirements?
- How do I apply?
- What's the minimum JAMB score?
- When are applications due?

### 2. **Course Registration** (Category ID: 2)
- Course registration procedures
- Registration deadlines
- How to use student portal
- Course requirements
- Prerequisites

**Sample Questions:**
- How do I register courses?
- When does registration close?
- Can I change registered courses?

### 3. **School Fees** (Category ID: 3)
- Fee schedules
- Payment procedures
- Payment channels
- Fee payment deadlines
- Fee deferrals/waivers

**Sample Questions:**
- How much are school fees?
- How do I pay fees?
- When is payment due?

### 4. **Examination** (Category ID: 4)
- Exam schedules
- Exam venues
- Examination regulations
- Result release dates
- Academic performance policies

**Sample Questions:**
- When are exams?
- Where is my exam venue?
- When will results be released?

### 5. **Academic Calendar** (Category ID: 5)
- Academic year dates
- Semester schedules
- Holiday dates
- Important academic dates
- Semester start/end dates

**Sample Questions:**
- When does the semester start?
- When are holidays?
- What's the academic calendar?

### 6. **Hostel Services** (Category ID: 6)
- Hostel applications
- Accommodation procedures
- Hostel policies
- Room allocation
- Hostel fees

**Sample Questions:**
- How do I apply for hostel?
- How much is hostel?
- When can I move into hostel?

### 7. **SIWES** (Category ID: 7)
- SIWES procedures
- Industrial placement
- Workplace requirements
- SIWES assessment
- Work experience period

**Sample Questions:**
- What is SIWES?
- How do I get a placement?
- How long is SIWES?

### 8. **Library Services** (Category ID: 8)
- Library registration
- Book borrowing procedures
- Library resources
- Library hours
- Library policies

**Sample Questions:**
- How do I register for library?
- How many books can I borrow?
- What are library hours?

### 9. **ICT Support** (Category ID: 9)
- Student portal login
- Password reset
- Technical support
- Portal features
- Internet access

**Sample Questions:**
- I can't log into the portal
- How do I reset my password?
- What's the student portal?

### 10. **Transcript Services** (Category ID: 10)
- Transcript requests
- Processing time
- Transcript fees
- Certificate issuance
- Academic records

**Sample Questions:**
- How do I request a transcript?
- How much does it cost?
- How long does it take?

### 11. **Graduation Requirements** (Category ID: 11)
- Graduation requirements
- Clearance procedures
- Final year requirements
- Convocation details
- Degree conferment

**Sample Questions:**
- What are graduation requirements?
- What do I need to graduate?
- When is convocation?

---

## 🚀 Knowledge Base Workflow

### User Query → AI Response

```
1. User asks: "How do I register my courses?"
                ▼
2. Query is processed (NLP)
   - Tokenized: ["how", "do", "i", "register", "courses"]
   - Lemmatized: ["how", "do", "register", "course"]
   - Embedded: [0.123, -0.456, ..., 0.789]
                ▼
3. Intent recognized: "course_registration" (confidence: 0.95)
   - Category determined: #2
                ▼
4. Semantic search in KB:
   - Find similar question embeddings
   - Retrieve top 3-5 matching entries
   - Similarity scores: [0.98, 0.87, 0.76]
                ▼
5. Build context:
   "Q: How do I register courses?
    A: You can register through the student portal...
    
    Q: What's the registration deadline?
    A: Registration closes on September 15..."
                ▼
6. Generate response (LLM):
   - Use OpenAI API
   - Provide context as background
   - Generate natural response
                ▼
7. Return to user:
   "You can register courses through the student portal.
    Steps: 1. Log in... 2. Select courses... 3. Submit..."
```

---

## 📥 Populating the Knowledge Base

### Method 1: Manual Admin Entry (Recommended)

**Steps:**

1. **Log into Admin Dashboard**
   - URL: http://localhost:5173/admin
   - Admin credentials required

2. **Click "Add KB Entry"**
   - Or: GET /api/admin/kb endpoint

3. **Fill in the Form:**

   ```
   Category:    ▼ [Admission]
   Question:    "What are the admission requirements?"
   Answer:      "To gain admission, you need:
                1. O-Level with 5 credits
                2. JAMB score of 120+
                3. Pass Post-UTME screening"
   Keywords:    "admission,requirements,JAMB,SSCE,entrance"
   Source:      "Admission Office Official Guide"
   Status:      ✓ Active
   ```

4. **Submit**
   - Entry is saved to database
   - Embeddings are generated automatically
   - Entry becomes searchable

**API Example:**
```bash
curl -X POST http://localhost:5000/api/admin/kb \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -d '{
    "categoryId": 1,
    "question": "What are the admission requirements?",
    "answer": "To gain admission...",
    "keywords": "admission,requirements,JAMB",
    "adminId": 1
  }'
```

### Method 2: Bulk CSV Import

**Process:**

1. **Prepare CSV File:**
   ```csv
   category,question,answer,keywords,source
   "Admission","What is ND?","National Diploma is...","ND,diploma","Handbook"
   "Admission","What are admission requirements?","You need...","admission,JAMB","Office"
   "Fees","How much are fees?","Fees are...","fees,payment","Bursary"
   ```

2. **Upload via API:**
   ```bash
   curl -X POST http://localhost:5000/api/admin/kb/import \
     -F "file=@kb_entries.csv" \
     -H "Authorization: Bearer <token>"
   ```

3. **System:**
   - Parses CSV
   - Validates entries
   - Batch inserts into database
   - Generates embeddings in background
   - Returns import report

### Method 3: PDF Document Extraction (Future)

```python
# Extract from PDF documents
documents = extract_pdfs([
    'student_handbook.pdf',
    'admission_guide.pdf',
    'policies.pdf'
])

# Parse into Q&A format
qa_pairs = parse_documents_to_qa(documents)

# Insert into KB
for qa in qa_pairs:
    add_to_kb(qa)
```

---

## 🔍 Semantic Search and Retrieval

### How It Works

**Traditional Keyword Search:**
```
User Query: "How do I register courses?"
Search for: "register" AND "courses"
Problem: Misses synonyms like "enroll", "sign up"
```

**Semantic Search (Embeddings):**
```
User Query: "How do I register courses?"
Embedding: [0.123, -0.456, ..., 0.789]

KB Entry 1: "How do I enroll in courses?"
Embedding: [0.121, -0.458, ..., 0.791]
Similarity: 0.98 ✓ MATCH!

KB Entry 2: "What's the weather?"
Embedding: [-0.654, 0.321, ..., -0.456]
Similarity: 0.12 ✗ NO MATCH
```

### Retrieval Algorithm

```python
def retrieve_kb_entries(query, top_n=5):
    # 1. Generate query embedding
    query_vec = embedding_model.encode(query)
    
    # 2. Get all KB embeddings
    kb_entries = db.query("SELECT * FROM knowledge_base WHERE status='active'")
    
    # 3. Calculate similarities
    scores = []
    for entry in kb_entries:
        similarity = cosine_similarity(
            query_vec,
            entry['question_embedding']
        )
        scores.append({
            'entry': entry,
            'score': similarity
        })
    
    # 4. Sort and return top N
    scores.sort(key=lambda x: x['score'], reverse=True)
    return scores[:top_n]

# Example
results = retrieve_kb_entries("How do I register?")
# Returns:
# [
#   {'entry': {...}, 'score': 0.98},  # Best match
#   {'entry': {...}, 'score': 0.87},
#   {'entry': {...}, 'score': 0.76},
#   {'entry': {...}, 'score': 0.65},
#   {'entry': {...}, 'score': 0.54}
# ]
```

---

## 📊 Knowledge Base Statistics

### Recommended KB Size

| Category | Recommended Entries | Example Topics |
|----------|-------------------|-----------------|
| Admission | 15-20 | Requirements, application, deadlines |
| Course Registration | 10-15 | Procedures, deadlines, portal use |
| School Fees | 10-15 | Schedules, payment, deferrals |
| Examination | 12-18 | Schedules, venues, regulations |
| Academic Calendar | 8-12 | Dates, holidays, semesters |
| Hostel Services | 10-15 | Application, policies, fees |
| SIWES | 8-12 | Procedures, placements, assessment |
| Library Services | 10-15 | Registration, borrowing, resources |
| ICT Support | 10-15 | Portal, login, passwords, issues |
| Transcript Services | 8-12 | Requests, fees, processing |
| Graduation | 12-18 | Requirements, clearance, dates |
| **TOTAL** | **~120-160** | **Covers most common queries** |

### Quality Metrics

**Coverage:**
- Target: 90% of common student questions answered
- Measure: Query resolution rate

**Accuracy:**
- Target: 95%+ accuracy of information
- Maintain by regular review

**Freshness:**
- Update: At least weekly
- Review: Every semester

---

## ✏️ Maintaining the Knowledge Base

### Regular Maintenance Tasks

**Weekly:**
- Review new queries that couldn't be answered
- Update outdated information
- Check for duplicate entries

**Monthly:**
- Analyze usage patterns
- Identify gaps in KB
- Add missing entries
- Remove outdated entries

**Semester:**
- Major review of all categories
- Update academic calendar
- Refresh admission/registration information
- Update fee schedules

**Yearly:**
- Comprehensive KB audit
- Remove/archive old entries
- Reorganize if needed
- Plan enhancements

### Update Procedure

**To Update an Entry:**

```bash
curl -X PUT http://localhost:5000/api/admin/kb/5 \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -d '{
    "question": "What are the new admission requirements?",
    "answer": "New information here...",
    "keywords": "admission,new,requirements",
    "status": "active"
  }'
```

**To Archive/Deactivate:**

```bash
curl -X PUT http://localhost:5000/api/admin/kb/5 \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -d '{
    "status": "archived"
  }'
```

---

## 🛡️ Data Quality Assurance

### Validation Checklist

Before adding an entry:

- [ ] Question is clear and specific
- [ ] Answer is complete and accurate
- [ ] Information is up-to-date
- [ ] Assigned to correct category
- [ ] Keywords are relevant
- [ ] Source is documented
- [ ] No duplicate entries exist
- [ ] Answer is not too long (< 500 words)
- [ ] Proper formatting and grammar

### Example of Good Entry:

```
✓ GOOD:
Category: Admission
Question: "What is the minimum JAMB score requirement?"
Answer: "The minimum JAMB score for admission is 120 points.
However, specific programs may require higher scores:
- Engineering: 150+
- Medicine: 170+
Contact Admission Office for your program."
Keywords: "JAMB,score,admission,requirement,120"
Source: "Admission Office 2024 Guidelines"
```

### Example of Bad Entry:

```
✗ BAD:
Category: Admission
Question: "tell me about admission plz"
Answer: "um admission is when u come to school"
Keywords: "stuff"
Source: "i dunno"

Problems:
- Question not clear
- Answer incomplete and informal
- Keywords vague
- Source not documented
- Not professional
```

---

## 🔄 Integration with AI Response Generation

### KB-Powered Response Flow

```
Step 1: Semantic Search
  Input: User query
  Process: Embedding similarity search
  Output: Top 5 KB entries

Step 2: Rank Results
  Process: Filter by confidence threshold (>0.6)
  Process: Remove duplicates
  Output: Filtered results

Step 3: Build Context
  Process: Combine Q&A pairs
  Process: Format for LLM
  Output: Prompt with context

Step 4: Generate Response (LLM)
  Input: Query + context + KB entries
  Process: OpenAI API call
  Output: Natural language response

Step 5: Validate Response
  Check: Response quality
  Check: Mentions sources
  Output: Final response to user
```

### Example Context Building

```python
def build_response_context(kb_results, user_query):
    context = f"""
    You are a helpful assistant for The Federal Polytechnic, Ado-Ekiti.
    
    User Query: {user_query}
    
    Relevant Information:
    """
    
    for i, result in enumerate(kb_results, 1):
        context += f"""
        
        Source {i}:
        Q: {result['question']}
        A: {result['answer']}
        (Similarity: {result['score']:.2%})
        """
    
    context += """
    
    Based on the above information, provide a helpful, accurate response.
    If information is not available, suggest contacting the relevant office.
    """
    
    return context
```

---

## 📈 Analytics and Monitoring

### Track KB Usage

```sql
SELECT 
    kb.id,
    kb.question,
    kb.category_id,
    COUNT(cm.id) as times_used,
    AVG(CAST(fb.rating as FLOAT)) as avg_rating
FROM knowledge_base kb
LEFT JOIN chat_messages cm ON kb.id = cm.kb_used
LEFT JOIN feedback fb ON cm.id = fb.message_id
GROUP BY kb.id
ORDER BY times_used DESC
LIMIT 20;
```

### Identify Gaps

Queries that:
- Can't find matching KB entry
- Get low user ratings
- Require multiple follow-ups

These indicate KB gaps to fill.

---

## 🚀 Best Practices

### 1. Keep It Simple
- Write clear, concise answers
- Use bullet points
- Avoid jargon when possible

### 2. Be Accurate
- Verify all information
- Document sources
- Update regularly

### 3. Be Complete
- Answer the "why" not just "how"
- Provide context
- Include contact info when needed

### 4. Use Good Keywords
```
✓ GOOD:  "registration,course,enrollment,add,drop,deadline"
✗ BAD:   "stuff"
```

### 5. Organize by Category
- One entry = one topic
- Clear category assignment
- No overlap between categories

### 6. Maintain Consistency
- Use same terminology
- Follow same format
- Regular review

---

## 🔗 Example Complete KB Entry

```
ID: 42
Category: Course Registration
Question: "How do I drop a course after registration?"

Answer: 
"You can drop a course through the student portal or in person 
at the Academic Affairs office.

Via Portal:
1. Log in to the student portal
2. Navigate to 'My Courses'
3. Select the course to drop
4. Click 'Drop Course'
5. Confirm the action
6. Print receipt for your records

In Person:
- Visit Academic Affairs Office (Administration Building, Room 203)
- Fill out course change form
- Get approval from your HOD
- Submit to Academic Affairs
- Keep a copy for your records

Important:
- Dropping must be within 2 weeks of semester start
- Academic penalty may apply if dropping after deadline
- Consult your academic advisor before dropping
- Some courses cannot be dropped

For questions: Contact Academic Affairs at (034) 123-4567 
or email academic@fedpolyado.edu.ng"

Keywords: "drop,course,registration,portal,academic affairs,deadline,course change"

Source: "Academic Affairs Office - Course Management Procedures Manual v2024"

Status: active

Created By: Admin (ID: 1)

Created At: 2024-01-15 09:00:00

Last Updated: 2024-01-15 14:30:00
```

---

## 📞 Support for KB Management

If you have questions about:
- **Adding entries:** See Method 1 (Manual Entry)
- **Bulk import:** See Method 2 (CSV Import)
- **Search not working:** Check embeddings are generated
- **Accuracy issues:** Review source documentation
- **Category assignment:** Refer to the 11 categories list
- **Technical issues:** Check Backend/AI Service logs

---

## ✅ KB Implementation Checklist

- [ ] Database schema created
- [ ] All 11 categories defined
- [ ] At least 3 sample entries per category (33 minimum)
- [ ] Embeddings generating correctly
- [ ] Semantic search working
- [ ] Admin interface for adding entries
- [ ] Admin interface for updating entries
- [ ] Admin interface for deleting entries
- [ ] KB coverage: 80%+ of common queries
- [ ] Data quality: 95%+ accuracy
- [ ] Regular maintenance schedule established
- [ ] Analytics dashboard set up
- [ ] Monitoring and alerts configured
- [ ] Documentation complete
- [ ] Training provided to admins

---

## 🎯 Next Steps

1. **Start Small:** Add 30-40 entries (3-4 per category)
2. **Test:** Make sure search and retrieval works
3. **Gather Feedback:** Track what queries students ask
4. **Expand:** Grow KB based on actual usage
5. **Optimize:** Remove weak entries, enhance strong ones
6. **Monitor:** Track performance metrics regularly
7. **Maintain:** Keep information fresh and accurate

The better your knowledge base, the better your AI assistant performs!
